package CompletableFutureDemo;

/**
 * created by suhail.jahangir on 25/09/20
 */
public class Student {
    public String name;
    public String id;
}
