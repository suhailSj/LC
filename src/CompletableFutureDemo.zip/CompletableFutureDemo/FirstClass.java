package CompletableFutureDemo;

import java.util.concurrent.CompletableFuture;

/**
 * created by suhail.jahangir on 25/09/20
 */
public class FirstClass {

    public CompletableFuture<Student> getStudent(){
        System.out.println("FirstClass : Inside Get Student ....");
        CompletableFuture<String> nameFuture = SecondClass.getStudentName();
        CompletableFuture<String> idFuture = ThirdClass.getStudentId();
        System.out.println("FirstClass : after creating 2 future");

        //when we want to combine two futures, we use thenCombine, first parameter is the future with which
        // we want to combine, other argument is the result of first future and result of second future
        return nameFuture.thenCombine(idFuture, (nameFutureResult, idFutureResult) -> {
            Student student = new Student();
            student.name = nameFutureResult;
            student.id = idFutureResult;
            return student;
        });
    }
}
