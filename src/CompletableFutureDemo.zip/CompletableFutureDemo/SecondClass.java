package CompletableFutureDemo;

import java.util.concurrent.CompletableFuture;

/**
 * created by suhail.jahangir on 25/09/20
 */
public class SecondClass {
    public static CompletableFuture<String> getStudentName() {
        System.out.println("SecondClass : Inside getStudentName ....");
        return CompletableFuture.completedFuture("Rocking Raksha");
    }
}
